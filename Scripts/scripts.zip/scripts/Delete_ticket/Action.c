Action()
{	
	lr_start_transaction("Delete_ticket");
	
	lr_start_transaction("open_home_page");
		web_reg_find("Text=/WebTours/home.html",
			LAST);
			web_add_auto_header("Sec-Fetch-Site", 
				"none");
			web_add_auto_header("Sec-Fetch-Dest", 
				"document");
			web_add_auto_header("Sec-Fetch-Mode", 
				"navigate");
			web_add_auto_header("Sec-Fetch-User", 
				"?1");
			web_add_auto_header("Upgrade-Insecure-Requests", 
				"1");
			web_add_auto_header("sec-ch-ua", 
				"\"Google Chrome\";v=\"111\", \"Not(A:Brand\";v=\"8\", \"Chromium\";v=\"111\"");
			web_add_auto_header("sec-ch-ua-mobile", 
				"?0");
			web_add_auto_header("sec-ch-ua-platform", 
				"\"Windows\"");
		/*Correlation comment - Do not change!  Original value='136136.370838396HAAcfVtpfHftcAVfpAiHtf' Name ='userSession' Type ='ResponseBased'*/
		web_reg_save_param_attrib(
			"ParamName=userSession",
			"TagName=input",
			"Extract=value",
			"Name=userSession",
			"Type=hidden",
			SEARCH_FILTERS,
			"IgnoreRedirections=No",
			"RequestUrl=*/nav.pl*",
			LAST);
			web_url("WebTours", 
					"URL=http://localhost:1080/WebTours/", 
					"TargetFrame=", 
					"Resource=0", 
					"RecContentType=text/html", 
					"Referer=", 
					"Snapshot=t1.inf", 
					"Mode=HTML", 
					LAST);
		lr_end_transaction("open_home_page", LR_AUTO);
		lr_think_time(29);
	
	lr_start_transaction("enter_login");
		web_reg_find("Text/IC=User password was correct",
		LAST);
		web_reg_find("Text/IC=Welcome, <b>{userName}</b>, to the Web Tours",
		LAST);

			web_revert_auto_header("Sec-Fetch-User");
			web_add_header("Origin", 
				"http://localhost:1080");
			web_add_auto_header("Sec-Fetch-Dest", 
				"frame");
			web_add_auto_header("Sec-Fetch-Site", 
				"same-origin");
			web_submit_data("login.pl",
			"Action=http://localhost:1080/cgi-bin/login.pl",
			"Method=POST",
			"TargetFrame=body",
			"RecContentType=text/html",
			"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home",
			"Snapshot=t2.inf",
			"Mode=HTML",
			ITEMDATA,
			"Name=userSession", "Value={userSession}", ENDITEM,
			"Name=username", "Value={userName}", ENDITEM,
			"Name=password", "Value={password}", ENDITEM,
			"Name=login.x", "Value=69", ENDITEM,
			"Name=login.y", "Value=9", ENDITEM,
			"Name=JSFormSubmit", "Value=off", ENDITEM,
			LAST);
		lr_end_transaction("enter_login", LR_AUTO);

	
	lr_start_transaction("itinerary_click");
	
	web_reg_save_param("flightID",
		"LB/IC=SID&",
		"RB/IC=;",
		LAST);
	
	web_reg_find("Fail=Found",
		"Text/IC={flightID}",
		LAST);

	
	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\"Google Chrome\";v=\"111\", \"Not(A:Brand\";v=\"8\", \"Chromium\";v=\"111\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(243);

	web_url("welcome.pl_2", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("itinerary_click",LR_AUTO);

	lr_start_transaction("cancel_click");
	
	web_reg_find("Fail=Found",
		"Text/IC={flightID}",
		LAST);

	web_add_header("Origin", 
		"http://localhost:1080");

	lr_think_time(77);
	
	web_submit_form("itinerary.pl", 
		"Snapshot=t4.inf", 
		ITEMDATA, 
		"Name=1", "Value=On", ENDITEM, 
		"Name=removeFlights.x", "Value=44", ENDITEM, 
		"Name=removeFlights.y", "Value=8", ENDITEM,
		LAST);

	lr_end_transaction("cancel_click",LR_AUTO);
	lr_end_transaction("Delete_ticket", LR_AUTO);

	return 0;
}