Action()
{

	lr_start_transaction("UC6_BuyTicket");
	
		web_add_cookie("googtrans=/auto/ru; DOMAIN=localhost");
		
		web_add_cookie("MSO=SID&1680601486; DOMAIN=localhost");
		
		lr_start_transaction("open_home_page");
		
		web_reg_find("Text=/WebTours/home.html",
			LAST);
		
			web_add_auto_header("Sec-Fetch-Site", 
				"none");
			web_add_auto_header("Sec-Fetch-Dest", 
				"document");
			web_add_auto_header("Sec-Fetch-Mode", 
				"navigate");
			web_add_auto_header("Sec-Fetch-User", 
				"?1");
			web_add_auto_header("Upgrade-Insecure-Requests", 
				"1");
			web_add_auto_header("sec-ch-ua", 
				"\"Google Chrome\";v=\"111\", \"Not(A:Brand\";v=\"8\", \"Chromium\";v=\"111\"");
			web_add_auto_header("sec-ch-ua-mobile", 
				"?0");
			web_add_auto_header("sec-ch-ua-platform", 
				"\"Windows\"");
		
		/*Correlation comment - Do not change!  Original value='136136.370838396HAAcfVtpfHftcAVfpAiHtf' Name ='userSession' Type ='ResponseBased'*/
		web_reg_save_param_attrib(
			"ParamName=userSession",
			"TagName=input",
			"Extract=value",
			"Name=userSession",
			"Type=hidden",
			SEARCH_FILTERS,
			"IgnoreRedirections=No",
			"RequestUrl=*/nav.pl*",
			LAST);
		
		web_url("WebTours", 
			"URL=http://localhost:1080/WebTours/", 
			"TargetFrame=", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Referer=", 
			"Snapshot=t1.inf", 
			"Mode=HTML", 
			LAST);
		
		lr_end_transaction("open_home_page", LR_AUTO);
		
		lr_think_time(5);
		
		lr_start_transaction("login");
		
		web_reg_find("Text/IC=User password was correct",
		LAST);
		
		web_reg_find("Text/IC=Welcome, <b>{userName}</b>, to the Web Tours",
		LAST);

			web_revert_auto_header("Sec-Fetch-User");
			
			web_add_header("Origin", 
				"http://localhost:1080");
			
			web_add_auto_header("Sec-Fetch-Dest", 
				"frame");
			
			web_add_auto_header("Sec-Fetch-Site", 
				"same-origin");
			
			web_submit_data("login.pl",
			"Action=http://localhost:1080/cgi-bin/login.pl",
			"Method=POST",
			"TargetFrame=body",
			"RecContentType=text/html",
			"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home",
			"Snapshot=t2.inf",
			"Mode=HTML",
			ITEMDATA,
			"Name=userSession", "Value={userSession}", ENDITEM,
			"Name=username", "Value={userName}", ENDITEM,
			"Name=password", "Value={password}", ENDITEM,
			"Name=login.x", "Value=69", ENDITEM,
			"Name=login.y", "Value=9", ENDITEM,
			"Name=JSFormSubmit", "Value=off", ENDITEM,
			LAST);
			
		lr_end_transaction("login", LR_AUTO);
		
		lr_think_time(5);
		
		lr_start_transaction("click_flights");
		
		web_reg_find("Text=Flight Selections",
		LAST);
		
			web_add_auto_header("Sec-Fetch-User", 
				"?1");

			web_url("Search Flights Button", 
					"URL=http://localhost:1080/cgi-bin/welcome.pl?page=search", 
					"TargetFrame=body", 
					"Resource=0", 
					"RecContentType=text/html", 
					"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
					"Snapshot=t3.inf", 
					"Mode=HTML", 
					LAST);
		
		lr_end_transaction("click_flights", LR_AUTO);
		
		lr_think_time(5);
		
		lr_start_transaction("click_reservation");
		
		web_reg_find("Text=reserveFlights",
		LAST);
		
			web_add_auto_header("Origin", 
				"http://localhost:1080");
			
		web_reg_find("Text/IC=departing from <B>{depart_city}</B> to <B>{arrive_city}</B>",
		LAST);

		/*Correlation comment - Do not change!  Original value='011;343;04/05/2023' Name ='outboundFlight' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=outboundFlight",
		"TagName=input",
		"Extract=value",
		"Name=outboundFlight",
		"Type=radio",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		LAST);

	web_submit_data("reservations.pl",
					"Action=http://localhost:1080/cgi-bin/reservations.pl", 
					"Method=POST", 
					"TargetFrame=", 
					"RecContentType=text/html", 
					"Referer=http://localhost:1080/cgi-bin/reservations.pl?page=welcome", 
					"Snapshot=t4.inf", 
					"Mode=HTML", 
					ITEMDATA, 
					"Name=advanceDiscount", "Value=0", ENDITEM, 
					"Name=depart", "Value={depart_city}", ENDITEM, 
					"Name=departDate", "Value={depart_date}", ENDITEM, 
					"Name=arrive", "Value={arrive_city}", ENDITEM, 
					"Name=returnDate", "Value={returnDate}", ENDITEM, 
					"Name=numPassengers", "Value=1", ENDITEM, 
					"Name=seatPref", "Value={seatPref}", ENDITEM, 
					"Name=seatType", "Value={seatType}", ENDITEM, 
					"Name=findFlights.x", "Value=64", ENDITEM, 
					"Name=findFlights.y", "Value=3", ENDITEM, 
					"Name=.cgifields", "Value=roundtrip", ENDITEM, 
					"Name=.cgifields", "Value=seatType", ENDITEM, 
					"Name=.cgifields", "Value=seatPref", ENDITEM, 
					LAST);
		
		lr_end_transaction("click_reservation", LR_AUTO);
		
		lr_think_time(5);
		
		lr_start_transaction("click_reservation_pl");
		
		web_reg_find("Text=Flight Reservation",
		LAST);
		
			web_submit_data("reservations.pl_2",
		"Action=http://localhost:1080/cgi-bin/reservations.pl",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=http://localhost:1080/cgi-bin/reservations.pl",
		"Snapshot=t5.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=outboundFlight", "Value={outboundFlight}", ENDITEM,
		"Name=numPassengers", "Value=1", ENDITEM,
		"Name=advanceDiscount", "Value=0", ENDITEM,
		"Name=seatType", "Value={seatType}", ENDITEM,
		"Name=seatPref", "Value={seatPref}", ENDITEM,
		"Name=reserveFlights.x", "Value=20", ENDITEM,
		"Name=reserveFlights.y", "Value=4", ENDITEM,
		LAST);
		
		lr_end_transaction("click_reservation_pl", LR_AUTO);
		
		lr_think_time(5);
		
		lr_start_transaction("buy_ticket");
		
		web_reg_find("Text=Reservation Made!",
		LAST);
		
			web_submit_data("reservations.pl_3",
		"Action=http://localhost:1080/cgi-bin/reservations.pl",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=http://localhost:1080/cgi-bin/reservations.pl",
		"Snapshot=t6.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=firstName", "Value={first_name}", ENDITEM,
		"Name=lastName", "Value={last_name}", ENDITEM,
		"Name=address1", "Value={adress_1}", ENDITEM,
		"Name=address2", "Value={adress_2}", ENDITEM,
		"Name=pass1", "Value={first_name} {last_name}", ENDITEM,
		"Name=creditCard", "Value={credit_card}", ENDITEM,
		"Name=expDate", "Value={exp_date}", ENDITEM,
		"Name=oldCCOption", "Value=", ENDITEM,
		"Name=numPassengers", "Value=1", ENDITEM,
		"Name=seatType", "Value={seatType}", ENDITEM,
		"Name=seatPref", "Value={seatPref}", ENDITEM,
		"Name=outboundFlight", "Value={outboundFlight}", ENDITEM,
		"Name=advanceDiscount", "Value=0", ENDITEM,
		"Name=returnFlight", "Value=", ENDITEM,
		"Name=JSFormSubmit", "Value=off", ENDITEM,
		"Name=buyFlights.x", "Value=46", ENDITEM,
		"Name=buyFlights.y", "Value=6", ENDITEM,
		"Name=.cgifields", "Value=saveCC", ENDITEM,
		LAST);
		
		lr_end_transaction("buy_ticket", LR_AUTO);
		
	lr_end_transaction("UC6_BuyTicket", LR_AUTO);

	return 0;
}